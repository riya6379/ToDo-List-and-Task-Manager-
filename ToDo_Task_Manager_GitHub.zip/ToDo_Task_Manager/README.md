# To-Do List and Task Manager (C++)

A menu-driven console project built using **Object-Oriented Programming**, a **singly linked list**, searching, sorting, and file handling.

## Team modules

| Module | Name | Main work |
|---|---|---|
| 1 | Task Creation | Add a task with title, priority, deadline and pending status. Each task is stored in a linked-list node. |
| 2 | Task Update and Deletion | Edit task details, mark a task completed, and delete a task by ID. |
| 3 | Task Sorting | Bubble-sort the linked list by priority, deadline, or title. |
| 4 | Task Display and Filter | Display all, pending or completed tasks; search titles by keyword. |
| 5 | Data Storage and Progress Summary | Save/load tasks using a text file and display completion statistics. |

## DSA concepts used

- **Singly Linked List:** Each node stores one task and a pointer to the next node.
- **Traversal:** Used to display, search, count, and append tasks.
- **Bubble Sort:** Used to sort tasks by priority, deadline, and title.
- **Linear Search:** Used to find a task by ID or title keyword.

## Priority scale

- `1` = High
- `2` = Medium-High
- `3` = Medium
- `4` = Low-Medium
- `5` = Low

The deadline must be entered in `YYYY-MM-DD` format. This format allows dates to be sorted correctly as strings.

## Project structure

```text
ToDo_Task_Manager/
├── src/
│   ├── Task.h
│   ├── TaskManager.h
│   ├── TaskManager.cpp
│   └── main.cpp
├── .gitignore
├── CMakeLists.txt
└── README.md
```

## Requirements

- C++ compiler supporting C++17 (G++, MinGW, or MSVC)
- VS Code is recommended but not compulsory

## Compile and run (VS Code terminal / Windows MinGW)

Open the project folder in VS Code, then run:

```bash
g++ -std=c++17 -Wall -Wextra src/main.cpp src/TaskManager.cpp -o todo
```

On Windows:

```bash
.\todo.exe
```

On Linux/macOS:

```bash
./todo
```

The program creates `tasks.txt` in the current working directory when tasks are saved. It loads that file automatically the next time it starts.

## Suggested test cases

1. Add at least three tasks with different priorities and deadlines.
2. Display all tasks and verify their IDs.
3. Update one task's title, priority, or deadline.
4. Mark one task as completed.
5. Delete a task and check that it no longer appears.
6. Sort by priority, deadline, and title.
7. Search for a word contained in a task title.
8. Display pending/completed tasks and the progress summary.
9. Save, close, and reopen the program. Confirm that saved tasks are loaded.

## Notes

- Task IDs are assigned automatically and are not reused after deletion.
- Sorting changes the order of nodes' task data; it does not change task IDs.
- The deadline check validates the requested format, not whether the calendar date (for example, February 30) is real.
- `tasks.txt` is runtime data and is intentionally excluded from Git using `.gitignore`.
